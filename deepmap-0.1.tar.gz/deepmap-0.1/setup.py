from setuptools import setup, find_packages

setup(
    name='deepmap',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'numpy',
        'pandas',
        'scanpy',
        'matplotlib',
        'torch',
        'scipy',
        'hnswlib',
        'importlib-metadata==6.0.0',
        'umap-learn==0.5.3'
    ],
)
