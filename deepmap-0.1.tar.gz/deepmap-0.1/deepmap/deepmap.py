import numpy as np
import pandas as pd
import scanpy as sc
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import os
from scipy.spatial.distance import cdist
import time
import scipy
from scipy.sparse import issparse
import hnswlib

class AutoEncoder(nn.Module):
    
    def __init__(self, input_size, hidden_size, dim):
        
        super(AutoEncoder, self).__init__()
        
        self.encoder = nn.Sequential(nn.Linear(input_size, hidden_size),
                                     nn.ReLU(),
                                     nn.Linear(hidden_size, hidden_size // 2),
                                     nn.ReLU(),
                                     nn.Linear(hidden_size // 2, hidden_size // 4),
                                     nn.ReLU(),
                                     nn.Linear(hidden_size // 4, dim))
        
        self.decoder = nn.Sequential(nn.Linear(dim, hidden_size // 4),
                                     nn.ReLU(),
                                     nn.Linear(hidden_size // 4, hidden_size // 2),
                                     nn.ReLU(),
                                     nn.Linear(hidden_size //2, hidden_size),
                                     nn.ReLU(),
                                     nn.Linear(hidden_size, input_size))
    
    def forward(self, x):
        
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        
        return encoded, decoded


def get_nn(df1, df2, metric = 'cosine', k = 10):
    
    """Find nearest neighbor between df1(reference) and df2(query)"""
    
    n = df1.shape[0]
    p = df1.shape[1]
    
    s = hnswlib.Index(space = metric, dim = p)
    s.init_index(max_elements = n, ef_construction = 200, M = 16)
    s.set_ef(int(k * 1.2))
    s.add_items(df1)
    ind, _ = s.knn_query(df2, k = k)
    
    match = set([(i, ind[i, j]) for i in range(df2.shape[0]) for j in range(k)])
    
    return match


def get_mnn(df1, df2, metric = 'cosine', k = 10, mnn_only = False):
    
    """Find mutual nearest neighbors between df1 and df2"""
    
    nn1 = get_nn(df1, df2, metric = metric, k = k)
    nn2 = get_nn(df2, df1, metric = metric, k = k)
    
    nn2 = set([(item[1], item[0]) for item in nn2])
    
    mnn = nn1 & nn2
    knn = nn1.union(nn2).difference(mnn)
    
    mnn = np.array([[item[0], item[1]] for item in mnn], dtype = np.int32)
    knn = np.array([[item[0], item[1]] for item in knn], dtype = np.int32)
    knn_dim = knn.shape[0]
    
    if mnn_only:
        
        return mnn
    
    return np.concatenate((mnn, knn[np.random.permutation(knn_dim)[:(knn_dim // 10)]]))


def cov(df, device = 'cpu'):
    
    p = df.shape[0]
    N = torch.eye(p) - torch.ones((p, 1)) @ torch.ones((1, p)) / p
    N = N.to(device)
    
    return df.T @ N @ df / (p - 1)


def matrix_cos_loss(df1, df2):
    
    return 1 - torch.trace(df1.T @ df2) / (torch.linalg.norm(df1) * torch.linalg.norm(df2))


class DeepMap():
    
    def __init__(self, metric = 'cosine', k = 10, mnn_only = False,
                 low_mem = False, device = None, verbose = True):
        
        if device is None:
        
            self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
            
        else:
            
            self.device = device
        
        self.k = k
        self.mnn_only = mnn_only
        self.metric = metric
        self.low_mem = low_mem
        self.verbose = verbose
    
    
    def preprocess(self, anndata, batch_key = 'batch', norm_log = True, hvg = True, gene_num = 4000, scale = True):
        
        self.adata = anndata
        self.batch_key = batch_key
        self.batch_names = self.adata.obs[self.batch_key].unique()
        self.n_batches = len(self.batch_names)
        self.sparse = issparse(self.adata.X)
        
        if norm_log:
            
            if self.verbose:
            
                print(time.ctime(time.time()), 'Data normalization ...')
        
            sc.pp.normalize_total(self.adata, target_sum = 1e4)
            sc.pp.log1p(self.adata)

        if hvg:
        
            if self.verbose:
            
                print(time.ctime(time.time()), 'Finding highly variable genes ...')
            
            sc.pp.highly_variable_genes(self.adata, n_top_genes = gene_num, batch_key = batch_key)
            self.adata = self.adata[:, self.adata.var.highly_variable_intersection]
            
            self.gene_num = self.adata.shape[1]
            
            if self.verbose:
                
                print(time.ctime(time.time()), 'Found {} highly variable genes'.format(self.gene_num))
                    
        else:
            
            self.gene_num = self.adata.shape[1]        
        
        if self.verbose:
            
            print(time.ctime(time.time()), 'Saving unscaled data ...')
        
        if not os.path.exists('tmp'):
            
            os.mkdir('tmp')
            
        for item in self.batch_names:
            
            self.adata[self.adata.obs[self.batch_key] == item].write('tmp/' + item + '.h5ad')
            
        if scale:
            
            if self.verbose:
            
                print(time.ctime(time.time()), 'Data Scaling ...')
            
            sc.pp.scale(self.adata, max_value = 10)
            
        if self.verbose:
            
            print(time.ctime(time.time()), 'Performing PCA ...')
        
        sc.tl.pca(self.adata, svd_solver = 'arpack')

    
    def integrate(self, hs = 512, dim = 20, lr = 1e-4, batch_size = 100, 
                  n_iters = None, n_reconstructs = 5, alpha = 1, beta = 0.1):
        
        if self.verbose:
            
            print(time.ctime(time.time()), 'Start integrating ...')
            
        if self.verbose:
            
            if self.device == 'cuda':
                
                print(time.ctime(time.time()), 'GPU used.')
                
            else:
                
                print(time.ctime(time.time()), 'CPU used.')
            
        if n_iters is None:
            
            n_iters = max(2000, 4 * self.adata.shape[0] // batch_size)
            
            if self.verbose:
                
                print(time.ctime(time.time()), 'Set n_iters = {}'.format(n_iters))
        
        time_s = time.time()
        
        if issparse(self.adata.X):
            
            self.adatas = [torch.FloatTensor(self.adata[self.adata.obs[self.batch_key] == item].X.todense()) for item in self.batch_names]
        
        else:
            
            self.adatas = [torch.FloatTensor(self.adata[self.adata.obs[self.batch_key] == item].X) for item in self.batch_names]
        
        self.pcs = [self.adata[self.adata.obs[self.batch_key] == item].obsm['X_pca'] for item in self.batch_names]
        self.obs_nums = [item.shape[0] for item in self.adatas]
        
        index_all = np.arange(self.adata.shape[0])
        self.index_list = [index_all[self.adata.obs[self.batch_key] == item] for item in self.batch_names]
        
        if self.low_mem:
            
            adata_tmp = [sc.read_h5ad('tmp/' + item + '.h5ad', backed = 'r+') for item in self.batch_names]
        
        else:
            
            adata_tmp = [sc.read_h5ad('tmp/' + item + '.h5ad').X for item in self.batch_names]
            
        if self.verbose:
            
            print(time.ctime(time.time()), 'Finding neighbors ...')
            
        time_ns = time.time()
        
        self.index_list = [get_mnn(self.pcs[j], self.pcs[i], 
                                   metric = self.metric, k = self.k, mnn_only = self.mnn_only) 
                           if j > i else [] 
                           for i in range(self.n_batches) 
                           for j in range(self.n_batches)]
        
        
        if self.verbose:
            
            time_used = np.round(time.time() - time_ns, 1)
            
            if time_used > 1:
            
                print(time.ctime(time.time()), 'Initial neighbor search completed, time used:', time_used, 'seconds.')
            
            else:
                
                print(time.ctime(time.time()), 'Initial neighbor search completed, time used:', time_used, 'second.')
            
        mse_loss = nn.MSELoss()
        
        self.autoencoder_list = [AutoEncoder(self.gene_num, hs, dim).to(self.device) for _ in range(self.n_batches)]
        optimizer = torch.optim.Adam([{'params': item.parameters()} for item in self.autoencoder_list], 
                                     lr = lr)
        
        self.loss_count1 = []
        self.loss_count2 = []
        self.loss_count3 = []
        
        flag = 1
        
        for i_iter in range(n_iters):
            
            csample_list = [np.random.permutation(item)[:batch_size] for item in self.obs_nums]
            
            self.enc_dec_list = [self.autoencoder_list[i](self.adatas[i][csample_list[i], :].to(self.device)) for i in range(self.n_batches)]
            
            pair_df_list = [[], []]
            
            for i in range(self.n_batches):
                
                for j in range(self.n_batches):
                    
                    if i >= j:
                        
                        continue
                        
                    else:
                        
                        index_tmp = self.index_list[i * self.n_batches + j]
                        
                        if len(index_tmp) > 0:
                            
                            csample_tmp = np.random.permutation(index_tmp.shape[0])[:min(batch_size, index_tmp.shape[0])]
                            
                            pair_df_list[0].append(self.autoencoder_list[i](self.adatas[i][index_tmp[csample_tmp, 0]].to(self.device))[0])
                            pair_df_list[1].append(self.autoencoder_list[j](self.adatas[j][index_tmp[csample_tmp, 1]].to(self.device))[0])
                        
            
            unscaled_adata = {}
            
            if self.low_mem:
                
                unscaled_adata = [adata_tmp[i][csample_list[i], :].to_memory().X for i in range(self.n_batches)]              
            
            else:
                
                unscaled_adata = [adata_tmp[i][csample_list[i], :] for i in range(self.n_batches)] 
            
            if self.sparse == True:
                
                unscaled_adata = [item.todense() for item in unscaled_adata]
                
            loss1 = sum([mse_loss(self.enc_dec_list[i][1], self.adatas[i][csample_list[i], :].to(self.device)) for i in range(self.n_batches)])
            
            loss2 = mse_loss(torch.cat(pair_df_list[0]), torch.cat(pair_df_list[1]))
            
            loss3 = sum([matrix_cos_loss(cov(torch.FloatTensor(unscaled_adata[i]).T.to(self.device), device = self.device), 
                                         cov(self.enc_dec_list[i][0].T, device = self.device)) for i in range(self.n_batches)])
            
            loss = loss1 + alpha * loss2 + beta * loss3 
            
            self.loss_count1.append(loss1.data.cpu().tolist())
            self.loss_count2.append(loss2.data.cpu().tolist())
            self.loss_count3.append(loss3.data.cpu().tolist())
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            if n_reconstructs > 0:

                if (i_iter >= (n_iters // 2)) & ((i_iter - (n_iters // 2)) % (n_iters // (2 * n_reconstructs)) == 0) & (flag <= n_reconstructs):

                    df_tmp_list = [self.autoencoder_list[i].to('cpu')(self.adatas[i])[0].data.numpy() for i in range(self.n_batches)]

                    if self.verbose:

                        print(time.ctime(time.time()), 'Reconstructing neighbors {}/{} ...'.format(flag, n_reconstructs))

                    self.index_list = [get_mnn(df_tmp_list[j], df_tmp_list[i], 
                                               metric = self.metric, k = self.k, mnn_only = self.mnn_only) 
                                       if j > i else [] 
                                       for i in range(self.n_batches) 
                                       for j in range(self.n_batches)]

                    for item in self.autoencoder_list:

                        item.to(self.device)

                    flag += 1
        
        df_tmp_list = [self.autoencoder_list[i].to('cpu')(self.adatas[i])[0].data.numpy() for i in range(self.n_batches)]
        
        self.integrated = sc.AnnData(X = np.vstack(df_tmp_list),
                                     obs = pd.concat([self.adata.obs[self.adata.obs['batch'] == item]
                                                      for item in self.batch_names]))
        self.integrated = self.integrated[self.adata.obs.index]
        
        print(time.ctime(time.time()), 'Integration finished.')
                