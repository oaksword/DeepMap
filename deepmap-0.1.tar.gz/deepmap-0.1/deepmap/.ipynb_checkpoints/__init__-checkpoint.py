from .deepmap import DeepMap

__version__ = '0.1'